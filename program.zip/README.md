# Project Description

## Smart contract
    Rock, Paper, Scissors Game

## How to build

    anchor build

##  How to deploy

    anchor deploy

## How to test

    anchor run test
