pub const GLOBAL_STATE_SEED: &[u8] = b"GLOBAL-STATE-SEED";
pub const VAULT_SEED: &[u8] = b"VAULT-SEED";
pub const ROUND_STATE_SEED: &[u8] = b"ROUND-STATE-SEED";